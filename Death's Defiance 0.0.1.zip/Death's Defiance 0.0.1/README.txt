Thanks for downloading Death's Defiance!

Controls:

HOLD Z to SPEED UP TEXT

PRESS X to SKIP TEXT TYPING

Have fun!